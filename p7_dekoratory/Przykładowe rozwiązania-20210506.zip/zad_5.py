def gen_dekorator(skala):    
    def dekoruj(old_fun):
        if (skala=='celcjusz'):
            def new_fun(x):
                return old_fun(x) - 273.15
        elif (skala=='fahrenheit'):
            def new_fun(x):
                return 32+9/5*(old_fun(x)-273.15)
        else:
            return old_fun(x)
        return new_fun
    return dekoruj
    

@gen_dekorator('celcjusz')
def get_temp(x):
    return(x)

print('%.2f K = %.2f C' %(0, get_temp(0)))
print('%.2f K = %.2f C' %(300, get_temp(300)))

@gen_dekorator('fahrenheit')
def get_temp(x):
    return(x)

print('%.2f K = %.2f F' %(0, get_temp(0)))
print('%.2f K = %.2f F' %(300, get_temp(300)))
