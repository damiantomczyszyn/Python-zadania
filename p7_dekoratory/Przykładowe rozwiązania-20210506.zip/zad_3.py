def dekoruj(old_fun):
    def new_fun(*args):
        return old_fun(*[i for i in args if type(i)==int])
    return new_fun
    
@dekoruj
def licz(*args):
    sum=0
    for i in args:
        sum+=i
    return sum

print(licz(2,4,6))
print(licz(100,'a',(1,2),5,440))
  