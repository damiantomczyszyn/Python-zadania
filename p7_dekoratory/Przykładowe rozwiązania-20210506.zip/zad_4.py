def dekoruj(old_fun):
    def new_fun(*args):
        global licz
        licz+=1
        return old_fun(*args)
    return new_fun

licz=0
    
@dekoruj
def fun1():
    pass

@dekoruj
def fun2():
    pass

@dekoruj
def fun3():
    pass

for i in range(5):
    fun1()
    fun2()
    fun3()

#liczba wywołań    
print(licz)    
    

