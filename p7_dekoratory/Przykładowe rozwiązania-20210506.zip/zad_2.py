class NotInteger(Exception):
    pass
      
def dekoruj(old_fun):
    d=['zero','jeden','dwa','trzy','cztery','pięć','sześć','siedem','osiem','dziewięć']
    def new_fun(a,b):
        if (type(old_fun(a,b)) == int):          
            return ' '.join([d[int(l)] for l in str(old_fun(a,b))])
        else:
            raise NotInteger('Nieprawidłowy argument - musi być liczba całkowita')
    return new_fun

    
@dekoruj
def dodaj(a,b):
    return(a+b)

print(dodaj(1000,440))

@dekoruj
def mnoz(x,y):
    return(x*y)
    
print(mnoz(4,5))

try:
    print(mnoz(2.2,5))
except NotInteger as ex:
    print(ex)
    
 