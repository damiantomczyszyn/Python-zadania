def dekorator(mathFun):
    d = ('zero','jeden','dwa','trzy','cztery','piec','szesc','siedem','osiem','dziewieć')        
    def newMathOper(x, y):
        if isinstance(mathFun(x, y), int):
            return ' '.join([d[int(x)] for x in str(mathFun(x, y))])
    return newMathOper


@dekorator
def mathOperAdd(x, y):
    return x + y


@dekorator
def mathOperMul(x, y):
    return x * y


print(mathOperAdd(12, 5))
print(mathOperMul(10, 5))
print(mathOperMul('a', 5))
